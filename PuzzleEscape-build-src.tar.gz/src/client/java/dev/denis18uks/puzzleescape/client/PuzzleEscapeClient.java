package dev.denis18uks.puzzleescape.client;

import dev.denis18uks.puzzleescape.client.network.ClientPackets;
import dev.denis18uks.puzzleescape.client.render.LivePortalRenderer;
import dev.denis18uks.puzzleescape.client.render.PiecePickupOverlay;
import dev.denis18uks.puzzleescape.client.render.PuzzleCanvasBlockEntityRenderer;
import dev.denis18uks.puzzleescape.client.render.PuzzlePieceEntityRenderer;
import dev.denis18uks.puzzleescape.registry.ModBlockEntities;
import dev.denis18uks.puzzleescape.registry.ModBlocks;
import dev.denis18uks.puzzleescape.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.render.RenderLayer;

public final class PuzzleEscapeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPackets.register();
        EntityRendererRegistry.register(ModEntities.PUZZLE_PIECE, PuzzlePieceEntityRenderer::new);
        BlockEntityRendererRegistry.register(ModBlockEntities.PUZZLE_CANVAS, PuzzleCanvasBlockEntityRenderer::new);
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.PUZZLE_CANVAS, RenderLayer.getTranslucent());
        PiecePickupOverlay.register();
        LivePortalRenderer.register();
    }
}
