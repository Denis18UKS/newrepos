package dev.denis18uks.puzzleescape.client.render;

import dev.denis18uks.puzzleescape.item.PuzzlePieceItem;
import dev.denis18uks.puzzleescape.registry.ModItems;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RotationAxis;

public final class PiecePickupOverlay {
    private static ItemStack stack = ItemStack.EMPTY;
    private static int ticks;
    private static int maxTicks;

    private PiecePickupOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(PiecePickupOverlay::render);
    }

    public static void show(String puzzleId, int piece, int rotation) {
        stack = PuzzlePieceItem.create(ModItems.PUZZLE_PIECE, puzzleId, piece, rotation);
        ticks = 26;
        maxTicks = ticks;
    }

    private static void render(DrawContext context, float tickDelta) {
        if (ticks <= 0 || stack.isEmpty()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.isPaused()) return;
        float age = (maxTicks - ticks + tickDelta) / Math.max(1f, maxTicks);
        float ease = (float) Math.sin(Math.min(1f, age) * Math.PI);
        float scale = 1.0f + 0.65f * ease;
        float wobble = (float) Math.sin(age * Math.PI * 5.0) * (1.0f - age) * 6.0f;
        int cx = context.getScaledWindowWidth() / 2;
        int cy = context.getScaledWindowHeight() / 2 - 18 - Math.round(ease * 18f);
        var matrices = context.getMatrices();
        matrices.push();
        matrices.translate(cx + wobble, cy, 250);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(wobble * 1.4f));
        matrices.scale(scale, scale, 1f);
        context.drawItem(stack, -8, -8);
        matrices.pop();
        if (tickDelta >= 0f) ticks--;
    }
}
