package dev.denis18uks.puzzleescape.client.render;

import dev.denis18uks.puzzleescape.PuzzleEscape;
import dev.denis18uks.puzzleescape.client.state.ClientPuzzleDefinition;
import dev.denis18uks.puzzleescape.client.state.PuzzleClientState;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import java.nio.ByteBuffer;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Renders the real destination world with a second camera into a small dynamic texture.
 * The texture is consumed by the assembled canvas block entities. A recursion guard is
 * mandatory because WorldRenderer#render fires Fabric world-render events again.
 */
public final class LivePortalRenderer {
    private static final int SIZE = 320;
    private static final Map<String, PortalTexture> TEXTURES = new HashMap<>();
    private static boolean renderingPortal;
    private static int frameCounter;

    private LivePortalRenderer() {}

    public static void register() {
        WorldRenderEvents.END.register(LivePortalRenderer::onWorldEnd);
    }

    public static Optional<Identifier> texture(String puzzleId) {
        PortalTexture texture = TEXTURES.get(puzzleId);
        return texture == null ? Optional.empty() : Optional.of(texture.id);
    }

    private static void onWorldEnd(WorldRenderContext context) {
        if (renderingPortal) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        if ((frameCounter++ & 1) != 0) return; // 10-30ish updates/s depending on FPS.

        ClientPuzzleDefinition def = PuzzleClientState.all().stream()
                .filter(ClientPuzzleDefinition::completed)
                .filter(d -> d.canvasOrigin().isPresent())
                .filter(d -> d.dimensionId().equals(client.world.getRegistryKey().getValue().toString()))
                .min(Comparator.comparingDouble(d -> Vec3d.ofCenter(d.canvasOrigin().orElseThrow()).squaredDistanceTo(context.camera().getPos())))
                .orElse(null);
        if (def == null) return;

        // Vanilla only keeps chunks around the real player in the client world. If the destination
        // is not present in the client's chunk cache, keep displaying the captured depth image fallback.
        BlockPos target = BlockPos.ofFloored(def.captureX(), def.captureY(), def.captureZ());
        if (!client.world.isChunkLoaded(target.getX() >> 4, target.getZ() >> 4)) return;

        try {
            renderDestination(context, client, def);
        } catch (Throwable t) {
            PuzzleEscape.LOGGER.warn("Live portal render failed for {}", def.id(), t);
        }
    }

    private static void renderDestination(WorldRenderContext context, MinecraftClient client, ClientPuzzleDefinition def) {
        renderingPortal = true;
        PortalTexture target = TEXTURES.computeIfAbsent(def.id(), id -> new PortalTexture(client, id));
        try {
            Vec3d cameraPos = mappedCameraPosition(context.camera().getPos(), def);
            PortalCamera camera = new PortalCamera();
            camera.update(client.world, client.player, false, false, context.tickDelta());
            camera.place(cameraPos, def.captureYaw(), def.capturePitch());

            target.framebuffer.beginWrite(true);
            target.framebuffer.setClearColor(0f, 0f, 0f, 1f);
            target.framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);
            client.worldRenderer.render(new MatrixStack(), context.tickDelta(), context.limitTime(), false,
                    camera, client.gameRenderer, client.gameRenderer.getLightmapTextureManager(),
                    client.gameRenderer.getBasicProjectionMatrix(client.options.getFov().getValue()));

            target.framebuffer.beginWrite(false);
            ByteBuffer pixels = BufferUtils.createByteBuffer(SIZE * SIZE * 4);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
            GL11.glReadPixels(0, 0, SIZE, SIZE, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, pixels);
            target.copyPixels(pixels);
            client.getFramebuffer().beginWrite(true);
        } finally {
            renderingPortal = false;
        }
    }

    private static Vec3d mappedCameraPosition(Vec3d viewer, ClientPuzzleDefinition def) {
        BlockPos origin = def.canvasOrigin().orElseThrow();
        Direction facing = def.canvasFacing();
        Direction right = facing.rotateYCounterclockwise();
        Vec3d rightVec = new Vec3d(right.getOffsetX(), 0, right.getOffsetZ());
        Vec3d normal = new Vec3d(facing.getOffsetX(), 0, facing.getOffsetZ());
        Vec3d center = Vec3d.ofCenter(origin)
                .add(rightVec.multiply((def.columns() - 1) * 0.5))
                .add(0, (def.rows() - 1) * 0.5, 0);
        Vec3d delta = viewer.subtract(center);
        double localRight = clamp(delta.dotProduct(rightVec), -4, 4);
        double localUp = clamp(delta.y, -3, 3);
        double localForward = clamp(delta.dotProduct(normal), 0, 5);

        double yawRad = Math.toRadians(def.captureYaw());
        Vec3d destForward = new Vec3d(-Math.sin(yawRad), 0, Math.cos(yawRad));
        Vec3d destRight = new Vec3d(destForward.z, 0, -destForward.x);
        // Center viewer reproduces the exact photographed camera. Lateral/vertical movement gives real parallax.
        return new Vec3d(def.captureX(), def.captureY(), def.captureZ())
                .add(destRight.multiply(localRight * 0.45))
                .add(0, localUp * 0.45, 0)
                .add(destForward.multiply((localForward - 1.5) * 0.08));
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }

    private static final class PortalCamera extends Camera {
        void place(Vec3d position, float yaw, float pitch) {
            setPos(position);
            setRotation(yaw, pitch);
        }
    }

    private static final class PortalTexture {
        final SimpleFramebuffer framebuffer = new SimpleFramebuffer(SIZE, SIZE, true, MinecraftClient.IS_SYSTEM_MAC);
        final NativeImageBackedTexture texture = new NativeImageBackedTexture(SIZE, SIZE, false);
        final Identifier id;

        PortalTexture(MinecraftClient client, String puzzleId) {
            String safe = puzzleId.replaceAll("[^A-Za-z0-9._-]", "_");
            id = client.getTextureManager().registerDynamicTexture("pe_live_" + safe, texture);
        }

        void copyPixels(ByteBuffer rgba) {
            NativeImage image = texture.getImage();
            if (image == null) return;
            for (int y = 0; y < SIZE; y++) {
                int srcY = SIZE - 1 - y;
                for (int x = 0; x < SIZE; x++) {
                    int index = (srcY * SIZE + x) * 4;
                    int r = rgba.get(index) & 255;
                    int g = rgba.get(index + 1) & 255;
                    int b = rgba.get(index + 2) & 255;
                    int a = rgba.get(index + 3) & 255;
                    image.setColor(x, y, r | (g << 8) | (b << 16) | (a << 24));
                }
            }
            texture.upload();
        }
    }
}
