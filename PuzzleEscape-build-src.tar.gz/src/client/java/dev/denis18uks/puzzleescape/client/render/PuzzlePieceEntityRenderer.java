package dev.denis18uks.puzzleescape.client.render;

import dev.denis18uks.puzzleescape.client.state.ClientPuzzleDefinition;
import dev.denis18uks.puzzleescape.client.state.PuzzleClientState;
import dev.denis18uks.puzzleescape.entity.PuzzlePieceEntity;
import dev.denis18uks.puzzleescape.item.PuzzlePieceItem;
import dev.denis18uks.puzzleescape.registry.ModItems;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public final class PuzzlePieceEntityRenderer extends EntityRenderer<PuzzlePieceEntity> {
    private final ItemRenderer itemRenderer;

    public PuzzlePieceEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
        this.shadowRadius = 0.35f;
    }

    @Override
    public void render(PuzzlePieceEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertices, int light) {
        matrices.push();
        ClientPuzzleDefinition def = PuzzleClientState.get(entity.getPuzzleId()).orElse(null);
        int shapeRotation = def == null ? 0 : ((def.column(entity.getPieceIndex()) + def.row(entity.getPieceIndex())) & 3);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((shapeRotation + entity.getPieceRotation()) * 90.0f));
        ItemStack stack = PuzzlePieceItem.create(ModItems.PUZZLE_PIECE, entity.getPuzzleId(), entity.getPieceIndex(), entity.getPieceRotation());
        itemRenderer.renderItem(stack, ModelTransformationMode.GROUND, light, OverlayTexture.DEFAULT_UV,
                matrices, vertices, entity.getWorld(), entity.getId());

        if (def != null) {
            Identifier texture = PuzzleClientState.texture(def.id()).orElse(null);
            if (texture != null) renderPhotoShape(matrices, vertices, light, def, texture, entity.getPieceIndex());
        }
        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertices, light);
    }

    private static void renderPhotoShape(MatrixStack matrices, VertexConsumerProvider providers, int light,
                                         ClientPuzzleDefinition def, Identifier texture, int piece) {
        if (piece < 0 || piece >= def.columns() * def.rows()) return;
        float u0 = def.column(piece) / (float) def.columns();
        float v0 = def.row(piece) / (float) def.rows();
        float du = 1.0f / def.columns();
        float dv = 1.0f / def.rows();
        VertexConsumer vc = providers.getBuffer(RenderLayer.getEntityTranslucent(texture));
        matrices.push();
        // Match the supplied Blockbench ground transform: translation Y=2/16, scale=0.5.
        matrices.translate(0.0, 0.064, 0.0);
        matrices.scale(0.50f, 0.50f, 0.50f);
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f p = entry.getPositionMatrix();
        Matrix3f n = entry.getNormalMatrix();
        // Supplied model top consists of 14x14 body + left 2x6 tab + top 6x2 tab.
        rect(vc, p, n, light, -0.375f, -0.375f, 0.50f, 0.50f,
                u0 + du * 0.125f, v0 + dv * 0.125f, u0 + du, v0 + dv);
        rect(vc, p, n, light, -0.50f, -0.125f, -0.375f, 0.25f,
                u0, v0 + dv * 0.375f, u0 + du * 0.125f, v0 + dv * 0.75f);
        rect(vc, p, n, light, -0.125f, -0.50f, 0.25f, -0.375f,
                u0 + du * 0.375f, v0, u0 + du * 0.75f, v0 + dv * 0.125f);
        matrices.pop();
    }

    private static void rect(VertexConsumer vc, Matrix4f p, Matrix3f n, int light,
                             float x0, float z0, float x1, float z1, float u0, float v0, float u1, float v1) {
        vertex(vc, p, n, x0, 0.02f, z1, u0, v1, light);
        vertex(vc, p, n, x1, 0.02f, z1, u1, v1, light);
        vertex(vc, p, n, x1, 0.02f, z0, u1, v0, light);
        vertex(vc, p, n, x0, 0.02f, z0, u0, v0, light);
    }

    private static void vertex(VertexConsumer vc, Matrix4f p, Matrix3f n, float x, float y, float z, float u, float v, int light) {
        vc.vertex(p, x, y, z).color(255, 255, 255, 255).texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(n, 0, 1, 0).next();
    }

    @Override
    public Identifier getTexture(PuzzlePieceEntity entity) {
        return SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE;
    }
}
